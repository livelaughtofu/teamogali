// noprotect
//─────────────────────────────────────────────
//   CIRCUITOS EN TINTA + RÍOS Y CAOS DE NÚMEROS + VERSOS EN LOS BORDES
//   Clic o ESPACIO = nueva imagen · tecla S = guardar PNG
// ─────────────────────────────────────────────

const W = 800;
const H = 1000;
const RM = 46;          // margen de los números
const MI = 66;          // margen interior
const G = 2;            // resolución de cuadrícula de ocupación más fina
const PAPEL = [255, 255, 255]; 
const PAPEL_CSS = "rgb(" + PAPEL.join(",") + ")";

let ctx, seed;
let occ, cols, rows;

const POEMA = `Let us go then, you and I,
When the evening is spread out against the sky
Like a patient etherized upon a table;
Let us go, through certain half-deserted streets,
The muttering retreats
Of restless nights in one-night cheap hotels
And sawdust restaurants with oyster-shells:
Streets that follow like a tedious argument
Of insidious intent
To lead you to an overwhelming question ...
Oh, do not ask, “What is it?”
Let us go and make our visit.
In the room the women come and go
Talking of Michelangelo.
The yellow fog that rubs its back upon the window-panes,
The yellow smoke that rubs its muzzle on the window-panes,
Licked its tongue into the corners of the evening,
Lingered upon the pools that stand in drains,
Let fall upon its back the soot that falls from chimneys,
Slipped by the terrace, made a sudden leap,
And seeing that it was a soft October night,
Curled once about the house, and fell asleep.
And indeed there will be time
For the yellow smoke that slides along the street,
Rubbing its back upon the window-panes;
There will be time, there will be time
To prepare a face to meet the faces that you meet;
There will be time to murder and create,
And time for all the works and days of hands
That lift and drop a question on your plate;
Time for you and time for me,
And time yet for a hundred indecisions,
And for a hundred visions and revisions,
Before the taking of a toast and tea.
And indeed there will be time
To wonder, “Do I dare?” and, “Do I dare?”
Time to turn back and descend the stair,
With a bald spot in the middle of my hair —
Do I dare
Disturb the universe?
In a minute there is time
For decisions and revisions which a minute will reverse.
For I have known them all already, known them all:
Have known the evenings, mornings, afternoons,
I have measured out my life with coffee spoons;
I know the voices dying with a dying fall
Beneath the music from a farther room.
So how should I presume?
And I have known the eyes already, known them all—
The eyes that fix you in a formulated phrase,
And when I am formulated, sprawling on a pin,
When I am pinned and wriggling on the wall,
Then how should I begin
To spit out all the butt-ends of my days and ways?
And how should I presume?
And I have known the arms already, known them all—
Arms that are braceleted and white and bare
Is it perfume from a dress
That makes me so digress?
Arms that lie along a table, or wrap about a shawl.
And should I then presume?
And how should I begin?
Shall I say, I have gone at dusk through narrow streets
And watched the smoke that rises from the pipes
Of lonely men in shirt-sleeves, leaning out of windows? ...
I should have been a pair of ragged claws
Scuttling across the floors of silent seas.
And the afternoon, the evening, sleeps so peacefully!
Smoothed by long fingers,
Asleep ... tired ... or it malingers,
Stretched on the floor, here beside you and me.
Should I, after tea and cakes and ices,
Have the strength to force the moment to its crisis?
But though I have wept and fasted, wept and prayed,
I have seen the moment of my greatness flicker,
And in short, I was afraid.
And would it have been worth it, after all,
After the cups, the marmalade, the tea,
Among the porcelain, among some talk of you and me,
Would it have been worth while,
To have bitten off the matter with a smile,
To have squeezed the universe into a ball
To roll it towards some overwhelming question,
It is impossible to say just what I mean!
But as if a magic lantern threw the nerves in patterns on a screen:
That is not what I meant, at all.
I grow old ... I grow old ...
I shall wear the bottoms of my trousers rolled.
Shall I part my hair behind? Do I dare to eat a peach?
I shall wear white flannel trousers, and walk upon the beach.
I have heard the mermaids singing, each to each.
I do not think that they will sing to me.
I have seen them riding seaward on the waves
Combing the white hair of the waves blown back
When the wind blows the water white and black.
We have lingered in the chambers of the sea
By sea-girls wreathed with seaweed red and brown
Till human voices wake us, and we drown.`
  .split("\n")
  .map((l) => l.trim())
  .filter((l) => l.length > 0);

function setup() {
  createCanvas(W, H);
  pixelDensity(1);
  ctx = drawingContext;
  noLoop();
  generar();
}

function generar() {
  seed = floor(random(1e9));
  randomSeed(seed);
  noiseSeed(seed);

  papel();

  cols = ceil(W / G);
  rows = ceil(H / G);
  occ = new Uint8Array(cols * rows);

  reservar(0, 0, W, MI);
  reservar(0, H - MI, W, MI);
  reservar(0, 0, MI, H);
  reservar(W - MI, 0, MI, H);

  // Coloca entre 6 y 9 chips muy chiquitos
  const chips = colocarChips();
  const lista = [];

  crearBuses(lista);

  const pines = [];
  for (const c of chips) {
    for (const p of pinesChip(c)) pines.push({ ...p, pad: false });
  }
  for (const a of pines) agregarPista(lista, a);

  const nSemillas = floor(random(150, 230));
  let sueltas = 0;
  for (let i = 0; i < 4000 && sueltas < nSemillas; i++) {
    const x = random(MI + 10, W - MI - 10);
    const y = random(MI + 10, H - MI - 10);
    if (!celdaLibre(x, y, 2)) continue;
    const ok = agregarPista(lista, {
      x, y,
      dir: floor(random(8)),
      w: random([0.4, 0.6, 0.8, 1.0]), // Muy delgadas, equivalente a 10-15px final o menos
      pad: true
    });
    if (ok) sueltas++;
  }

  const extras = crearExtras();

  // 1. Ríos de números de fondo
  rios();

  // Caos de números volando para "empapar" el lienzo
  numerosCaos();

  // 2. Circuitos en tinta
  dibujarCircuitos(lista, chips);
  dibujarExtras(extras);

  // 3. Versos en los bordes
  versosBorde();

  // 4. Textura leve (aprox. 40 puntos)
  puntitos();
}

function agregarPista(lista, a) {
  const pts = trazar(a);
  if (pts.length < 2) return false;
  lista.push({
    pts, w: a.w, r: 4,
    padIni: a.pad, padFin: random() < 0.9,
    radio: random(1.5, 3), // Pads más chiquitos acordes a líneas delgadas
    tipo: random(),
    normal: true
  });
  return true;
}

function papel() {
  background(255);
}

function puntitos() {
  // Solo ~40 puntos para emular leve ruido de film sin saturar
  noStroke();
  for (let i = 0; i < 40; i++) {
    fill(0, random(100, 180));
    rect(floor(random(W)), floor(random(H)), 1.2, 1.2);
  }
}

function rios() {
  const ox = random(1000), oy = random(1000);
  const base = random(TWO_PI);
  const amp = random(8, 18);
  const campo = (x, y) => base + (noise(x * 0.003 + ox, y * 0.003 + oy) - 0.5) * amp;

  const Gr = 3;
  const cr = ceil(W / Gr), rr_ = ceil(H / Gr);
  const occR = new Uint8Array(cr * rr_);
  const dsep = random(4.0, 4.5); // Más juntos para mayor caos
  const paso = 2.5;

  const libre = (x, y, d) => {
    if (x < RM || x > W - RM || y < RM || y > H - RM) return false;
    const rad = floor(d / Gr);
    const cx0 = floor(x / Gr), cy0 = floor(y / Gr);
    for (let dy = -rad; dy <= rad; dy++) {
      for (let dx = -rad; dx <= rad; dx++) {
        const cx = cx0 + dx, cy = cy0 + dy;
        if (cx < 0 || cy < 0 || cx >= cr || cy >= rr_) continue;
        if (occR[cy * cr + cx]) return false;
      }
    }
    return true;
  };

  const seguir = (x, y, sgn) => {
    const out = [];
    for (let i = 0; i < 500; i++) {
      const a = campo(x, y);
      x += cos(a) * paso * sgn;
      y += sin(a) * paso * sgn;
      if (!libre(x, y, dsep * 0.8)) break;
      out.push({ x, y });
    }
    return out;
  };

  const lineas = [];
  for (let t = 0; t < 60000; t++) { // Aumentadas tentativas para densificar
    const x = random(RM, W - RM), y = random(RM, H - RM);
    if (!libre(x, y, dsep)) continue;
    const fw = seguir(x, y, 1);
    const bw = seguir(x, y, -1).reverse();
    const pts = [...bw, { x, y }, ...fw];
    if (pts.length * paso < 30) continue;
    for (const p of pts) {
      const cx = floor(p.x / Gr), cy = floor(p.y / Gr);
      if (cx >= 0 && cy >= 0 && cx < cr && cy < rr_) occR[cy * cr + cx] = 1;
    }
    lineas.push(pts);
  }

  ctx.save();
  ctx.textAlign = "center";
ctx.textBaseline = "middle";
  ctx.shadowColor = "rgba(0,0,0,0.2)";
  ctx.shadowBlur = 0.4;

  for (const pts of lineas) {
    let acum = 0;
    let necesario = 0;
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1], b = pts[i];
      acum += dist(a.x, a.y, b.x, b.y);
      if (acum < necesario) continue;
      acum -= necesario;

      const x = b.x, y = b.y;
      const sz = constrain(map(noise(x * 0.005 + oy, y * 0.005 + ox), 0.2, 0.8, 6, 12), 6, 12);
      necesario = sz * 0.45;
      if (ocupadoCirc(x, y)) continue;

      const n2 = noise(x * 0.004 + ox * 3, y * 0.004 + oy * 3);
      let ch = str(floor(constrain(map(n2, 0.2, 0.8, 0, 9.99), 0, 9.99)));

      const alfa = constrain(0.45 + 0.8 * noise(x * 0.002 + ox, y * 0.002 + oy + 50), 0.35, 0.9);

      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(atan2(b.y - a.y, b.x - a.x));
      ctx.font = "italic bold " + sz.toFixed(1) + "px 'Courier New', monospace";
      ctx.fillStyle = "rgba(10,10,10," + alfa.toFixed(2) + ")";
      ctx.fillText(ch, 0, 0);
      ctx.restore();
    }
  }
  ctx.restore();
}

// Genera un enjambre descontrolado y caótico de números extra "volando"
function numerosCaos() {
  ctx.save();
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  
  // Genera miles de números adicionales dispersos y rotados caóticamente
  const cantidad = floor(random(2500, 4000));
  for (let i = 0; i < cantidad; i++) {
    const x = random(RM, W - RM);
    const y = random(RM, H - RM);
    
    // Evita chocar de lleno con el núcleo de los chips
    if (ocupadoCirc(x, y)) continue;

    const sz = random(5, 13);
    const ch = floor(random(0, 10)).toString();
    const rot = random(-PI, PI);
    const alfa = random(0.2, 0.85);

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rot);
    ctx.font = "italic bold " + sz.toFixed(1) + "px 'Courier New', monospace";
    ctx.fillStyle = "rgba(10,10,10," + alfa.toFixed(2) + ")";
    ctx.fillText(ch, 0, 0);
    ctx.restore();
  }
  ctx.restore();
}

function ocupadoCirc(x, y) {
  const cx0 = floor(x / G), cy0 = floor(y / G);
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      const cx = cx0 + dx, cy = cy0 + dy;
      if (cx < 0 || cy < 0 || cx >= cols || cy >= rows) continue;
      if (occ[cy * cols + cx]) return true;
    }
  }
  return false;
}

function ruta(pts, r) {
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y);
  for (let i = 1; i < pts.length - 1; i++) {
    const rad = min(r,
      dist(pts[i - 1].x, pts[i - 1].y, pts[i].x, pts[i].y) / 2,
      dist(pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y) / 2);
    ctx.arcTo(pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, rad);
  }
  const l = pts[pts.length - 1];
  ctx.lineTo(l.x, l.y);
}

function tinta(pts, w, r) {
  ctx.save();
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.shadowColor = "rgba(0,0,0,0.5)";
  ctx.shadowBlur = 1.0;
  ctx.strokeStyle = "rgba(8,8,8,0.95)";
  ctx.lineWidth = w;
  ruta(pts, r);
  ctx.stroke();

  ctx.shadowBlur = 0;
  ctx.translate(random(-0.25, 0.25), random(-0.25, 0.25));
  ctx.strokeStyle = "rgba(0,0,0,0.15)";
  ctx.lineWidth = w + 0.6;
  ruta(pts, r);
  ctx.stroke();
  ctx.restore();
}

function padTinta(x, y, r, tipo) {
  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.5)";
  ctx.shadowBlur = 1.0;
  ctx.strokeStyle = "rgba(8,8,8,0.95)";
  ctx.fillStyle = "rgba(8,8,8,0.95)";
  ctx.lineWidth = 0.8;
  if (tipo < 0.5) {
    ctx.fillStyle = PAPEL_CSS;
    ctx.beginPath(); ctx.arc(x, y, r, 0, TWO_PI); ctx.fill(); ctx.stroke();
  } else if (tipo < 0.85) {
    ctx.beginPath(); ctx.arc(x, y, r * 0.5, 0, TWO_PI); ctx.fill();
  } else {
    ctx.fillStyle = PAPEL_CSS;
    ctx.beginPath(); ctx.arc(x, y, r, 0, TWO_PI); ctx.fill(); ctx.stroke();
    ctx.fillStyle = "rgba(8,8,8,0.95)";
    ctx.beginPath(); ctx.arc(x, y, r * 0.3, 0, TWO_PI); ctx.fill();
  }
  ctx.restore();
}

function dibujarCircuitos(lista, chips) {
  // Usamos un factor de escala menor para que las líneas sean sumamente delgadas (de 10-15px final o menos)
  for (const t of lista) tinta(t.pts, t.w * 0.8, t.r);

  for (const t of lista) {
    const fin = t.pts[t.pts.length - 1], ini = t.pts[0];
    if (t.padFin) padTinta(fin.x, fin.y, t.radio, t.tipo);
    if (t.padIni) padTinta(ini.x, ini.y, t.radio * 0.8, (t.tipo * 7.3) % 1);
    if (t.normal) {
      for (let i = 1; i < t.pts.length - 1; i++) {
        if (random() < 0.2) padTinta(t.pts[i].x, t.pts[i].y, 1.2, random() < 0.5 ? 0.6 : 0.1);
      }
    }
  }

  const tramos = [];
  for (const t of lista) {
    if (!t.normal || t.w > 1.2) continue;
    for (let i = 0; i < t.pts.length - 1; i++) {
      const a = t.pts[i], b = t.pts[i + 1];
      if (dist(a.x, a.y, b.x, b.y) > 60) tramos.push({ a, b });
    }
  }
  shuffle(tramos, true);
  for (let i = 0; i < min(16, tramos.length); i++) componente(tramos[i]);

  for (const c of chips) dibujarChip(c);
}

function crearExtras() {
  const mats = [], barras = [];

  const nm = floor(random(20, 35));
  for (let i = 0; i < 400 && mats.length < nm; i++) {
    const cw = floor(random(2, 4)), ch = floor(random(2, 4)), sp = 3.0;
    const wpx = cw * sp, hpx = ch * sp;
    const x = random(MI + 10, W - MI - 10 - wpx);
    const y = random(MI + 10, H - MI - 10 - hpx);
    if (!rectLibre(x - 3, y - 3, wpx + 6, hpx + 6)) continue;
    reservar(x - 3, y - 3, wpx + 6, hpx + 6);
    mats.push({ x, y, cw, ch, sp });
  }

  const nb = floor(random(20, 35));
  for (let i = 0; i < 400 && barras.length < nb; i++) {
    const horiz = random() < 0.5;
    const l = random(5, 12), th = random(1.5, 2.5);
    const w = horiz ? l : th, h = horiz ? th : l;
    const x = random(MI + 10, W - MI - 10 - w);
    const y = random(MI + 10, H - MI - 10 - h);
    if (!rectLibre(x - 2, y - 2, w + 4, h + 4)) continue;
    reservar(x - 2, y - 2, w + 4, h + 4);
    barras.push({ x, y, w, h });
  }
  return { mats, barras };
}

function dibujarExtras(e) {
  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.45)";
  ctx.shadowBlur = 0.8;
  ctx.fillStyle = "rgba(8,8,8,0.95)";
  for (const m of e.mats) {
    for (let i = 0; i < m.cw; i++) {
      for (let j = 0; j < m.ch; j++) {
        ctx.beginPath();
        ctx.arc(m.x + (i + 0.5) * m.sp, m.y + (j + 0.5) * m.sp, 0.65, 0, TWO_PI);
        ctx.fill();
      }
    }
  }
  for (const b of e.barras) ctx.fillRect(b.x, b.y, b.w, b.h);
  ctx.restore();
}

function componente(t) {
  const mx = (t.a.x + t.b.x) / 2, my = (t.a.y + t.b.y) / 2;
  const ang = atan2(t.b.y - t.a.y, t.b.x - t.a.x);
  ctx.save();
  ctx.translate(mx, my);
  ctx.rotate(ang);
  ctx.shadowColor = "rgba(0,0,0,0.4)";
  ctx.shadowBlur = 0.8;
  ctx.strokeStyle = "rgba(8,8,8,0.95)";
  ctx.fillStyle = PAPEL_CSS;
  ctx.lineWidth = 0.8;
  if (random() < 0.6) {
    const lw = random(10, 18);
    ctx.fillRect(-lw / 2, -2, lw, 4);
    ctx.strokeRect(-lw / 2, -2, lw, 4);
  } else {
    ctx.fillRect(-3, -4, 6, 8);
    ctx.beginPath();
    ctx.moveTo(-1.2, -4); ctx.lineTo(-1.2, 4);
    ctx.moveTo(1.2, -4); ctx.lineTo(1.2, 4);
    ctx.lineWidth = 0.9;
    ctx.stroke();
  }
  ctx.restore();
}

function crearBuses(lista) {
  const nb = floor(random(3, 6));
  for (let b = 0; b < nb; b++) {
    for (let intento = 0; intento < 40; intento++) {
      const n = floor(random(4, 9));
      const sp = random(2.5, 3.8); // Muy compactas
      const tw = (n - 1) * sp;
      const x = random(MI + 40, W - MI - 40);
      const y = random(MI + 40, H - MI - 40);
      const rad = ceil(tw / 2 / G) + 2;
      if (!celdaLibre(x, y, rad)) continue;

      const pts = trazar({
        x, y, dir: floor(random(8)), w: tw + 1.5, pad: true,
        minLen: 50, maxLen: 120, maxSeg: floor(random(3, 5))
      });
      if (pts.length < 3) continue;

      const tipo = random();
      for (let k = 0; k < n; k++) {
        lista.push({
          pts: desplazar(pts, -tw / 2 + k * sp),
          w: 0.7, r: 0,
          padIni: true, padFin: true,
          radio: 1.5, tipo,
          normal: false
        });
      }
      break;
    }
  }
}

function desplazar(pts, off) {
  const out = [];
  const n = pts.length;
  for (let i = 0; i < n; i++) {
    let n0 = null, n1 = null;
    if (i > 0) {
      const dx = pts[i].x - pts[i - 1].x, dy = pts[i].y - pts[i - 1].y;
      const l = Math.hypot(dx, dy);
      n0 = { x: -dy / l, y: dx / l };
    }
    if (i < n - 1) {
      const dx = pts[i + 1].x - pts[i].x, dy = pts[i + 1].y - pts[i].y;
      const l = Math.hypot(dx, dy);
      n1 = { x: -dy / l, y: dx / l };
    }
    let nx, ny, k = 1;
    if (n0 && n1) {
      let mx = n0.x + n1.x, my = n0.y + n1.y;
      const ml = Math.hypot(mx, my);
      mx /= ml; my /= ml;
      k = 1 / max(mx * n0.x + my * n0.y, 0.3);
      nx = mx; ny = my;
    } else {
      const nn = n0 || n1;
      nx = nn.x; ny = nn.y;
    }
    out.push({ x: pts[i].x + nx * off * k, y: pts[i].y + ny * off * k });
  }
  return out;
}

// Coloca estrictamente entre 6 y 9 chips y muy chiquitos
function colocarChips() {
  const chips = [];
  const n = floor(random(6, 10)); // Entre 6 y 9 chips
  for (let i = 0; i < n; i++) {
    // Reducido tamaño 's' para que sean muy chiquitos y compactos
    const s = floor(random(32, 52));
    const np = floor(random(4, 7));
    const pl = 5;
    for (let t = 0; t < 100; t++) {
      const m = s / 2 + MI + 25;
      const x = random(m, W - m), y = random(m, H - m);
      const half = s / 2 + pl + 1;
      if (rectLibre(x - half, y - half, 2 * half, 2 * half)) {
        chips.push({ x, y, s, n: np, pl });
        reservar(x - half, y - half, 2 * half, 2 * half);
        break;
      }
    }
  }
  return chips;
}

function pinesChip(c) {
  const out = [];
  const pitch = c.s / c.n;
  for (let side = 0; side < 4; side++) {
    const ang = side * HALF_PI;
    for (let k = 0; k < c.n; k++) {
      const t = -c.s / 2 + pitch * (k + 0.5);
      const lx = c.s / 2 + c.pl, ly = t;
      out.push({
        x: c.x + lx * cos(ang) - ly * sin(ang),
        y: c.y + lx * sin(ang) + ly * cos(ang),
        dir: side * 2,
        w: 0.7
      });
    }
  }
  return out;
}

function dibujarChip(c) {
  const { x, y, s, n, pl } = c;
  const pitch = s / n;
  const pw = pitch * 0.45;

  ctx.save();
  ctx.translate(x, y);
  ctx.shadowColor = "rgba(0,0,0,0.5)";
  ctx.shadowBlur = 1.0;
  ctx.fillStyle = "rgba(8,8,8,0.96)";

  for (let side = 0; side < 4; side++) {
    ctx.save();
    ctx.rotate(side * HALF_PI);
    for (let k = 0; k < n; k++) {
      const t = -s / 2 + pitch * (k + 0.5);
      ctx.fillRect(s / 2 - 1, t - pw / 2, pl + 1, pw);
    }
    ctx.restore();
  }

  ctx.fillRect(-s / 2, -s / 2, s, s);

  ctx.shadowBlur = 0;
  ctx.strokeStyle = "rgba(243,239,228,0.5)";
  ctx.lineWidth = 0.6;
  ctx.strokeRect(-s / 2 + 3, -s / 2 + 3, s - 6, s - 6);

  ctx.fillStyle = "rgba(243,239,228,0.7)";
  ctx.beginPath();
  ctx.arc(-s / 2 + 6, -s / 2 + 6, 1.2, 0, TWO_PI);
  ctx.fill();

  ctx.font = "6px 'Courier New', monospace";
  ctx.textAlign = "center";
  ctx.fillStyle = "rgba(243,239,228,0.65)";
  const cod = floor(random(1e4, 9e4)).toString(16).toUpperCase();
  ctx.fillText(cod, 0, 2);
  ctx.restore();
}

function trazar(st) {
  const pts = [{ x: st.x, y: st.y }];
  let x = st.x, y = st.y, dir = st.dir;
  const maxSeg = st.maxSeg || floor(random(3, 8));
  const minLen = st.minLen || 20;
  const maxLen = st.maxLen || 110;

  for (let s = 0; s < maxSeg; s++) {
    let ok = false;
    for (let intento = 0; intento < 8; intento++) {
      let d = dir;
      if (s > 0) {
        const r = random();
        if (r < 0.35) d = dir;
        else if (r < 0.7) d = (dir + 1) % 8;
        else if (r < 0.95) d = (dir + 7) % 8;
        else d = (dir + (random() < 0.5 ? 2 : 6)) % 8;
      }
      let len = random(minLen, maxLen) * (d % 2 ? 0.8 : 1);
      if (s === 0 && st.pad === false) len = random(10, 45);
      const nx = x + cos(d * QUARTER_PI) * len;
      const ny = y + sin(d * QUARTER_PI) * len;
      if (segmentoLibre(x, y, nx, ny, st.w)) {
        marcarSegmento(x, y, nx, ny, st.w);
        pts.push({ x: nx, y: ny });
        x = nx; y = ny; dir = d;
        ok = true;
        break;
      }
    }
    if (!ok) break;
  }
  return pts;
}

function celda(px, py) {
  return floor(py / G) * cols + floor(px / G);
}

function celdaLibre(x, y, rad) {
  const cx0 = floor(x / G), cy0 = floor(y / G);
  for (let dy = -rad; dy <= rad; dy++) {
    for (let dx = -rad; dx <= rad; dx++) {
      const cx = cx0 + dx, cy = cy0 + dy;
      if (cx < 0 || cy < 0 || cx >= cols || cy >= rows) return false;
      if (occ[cy * cols + cx]) return false;
    }
  }
  return true;
}

function segmentoLibre(x0, y0, x1, y1, w) {
  if (x1 < MI || x1 > W - MI || y1 < MI || y1 > H - MI) return false;
  const L = dist(x0, y0, x1, y1);
  const rr = max(1, round((w / 2 + 1.5) / G));
  const salto = rr * G * 1.5 + 6;
  const paso = 2.0;
  const steps = ceil(L / paso);
  for (let i = 1; i <= steps; i++) {
    if (i * paso < salto) continue;
    const px = lerp(x0, x1, i / steps), py = lerp(y0, y1, i / steps);
    const cx0 = floor(px / G), cy0 = floor(py / G);
    for (let dy = -rr; dy <= rr; dy++) {
      for (let dx = -rr; dx <= rr; dx++) {
        const cx = cx0 + dx, cy = cy0 + dy;
        if (cx < 0 || cy < 0 || cx >= cols || cy >= rows) return false;
        if (occ[cy * cols + cx]) return false;
      }
    }
  }
  return true;
}

function marcarSegmento(x0, y0, x1, y1, w) {
  const L = dist(x0, y0, x1, y1);
  const rr = max(1, round((w / 2 + 1.5) / G));
  const steps = ceil(L / 1.5);
  for (let i = 0; i <= steps; i++) {
    const px = lerp(x0, x1, i / steps), py = lerp(y0, y1, i / steps);
    const cx0 = floor(px / G), cy0 = floor(py / G);
    for (let dy = -rr; dy <= rr; dy++) {
      for (let dx = -rr; dx <= rr; dx++) {
        const cx = cx0 + dx, cy = cy0 + dy;
        if (cx >= 0 && cy >= 0 && cx < cols && cy < rows) occ[cy * cols + cx] = 1;
      }
    }
  }
}

function rectLibre(x, y, w, h) {
  for (let py = y; py < y + h; py += G) {
    for (let px = x; px < x + w; px += G) {
      if (px < 0 || py < 0 || px >= W || py >= H) return false;
      if (occ[celda(px, py)]) return false;
    }
  }
  return true;
}

function reservar(x, y, w, h) {
  for (let py = max(0, y); py < min(H, y + h); py += G) {
    for (let px = max(0, x); px < min(W, x + w); px += G) {
      occ[celda(px, py)] = 1;
    }
  }
}

function versosBorde() {
  const ini = floor(random(POEMA.length));
  const flujo = [];
  for (let i = 0; i < 40; i++) flujo.push(POEMA[(ini + i) % POEMA.length]);
  const palabras = flujo.join(" / ").split(" ");

  const E = 58;
  const bordes = [
    { L: W - 2 * E, t: () => { ctx.translate(E, 30); } },
    { L: H - 2 * E, t: () => { ctx.translate(W - 30, E); ctx.rotate(HALF_PI); } },
    { L: W - 2 * E, t: () => { ctx.translate(W - E, H - 30); ctx.rotate(PI); } },
    { L: H - 2 * E, t: () => { ctx.translate(30, H - E); ctx.rotate(-HALF_PI); } }
  ];

  ctx.save();
  ctx.font = "italic 12px Georgia, 'Times New Roman', serif";
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
  const espMin = 3.5;
  let p = 0;

  for (const b of bordes) {
    const fila = [];
    let suma = 0;
    while (p < palabras.length) {
      const w = ctx.measureText(palabras[p]).width;
      if (suma + w + fila.length * espMin > b.L) break;
      fila.push({ t: palabras[p], w });
      suma += w;
      p++;
    }
    const gap = fila.length > 1 ? min((b.L - suma) / (fila.length - 1), 18) : 0;

    ctx.save();
    b.t();
    ctx.shadowColor = "rgba(0,0,0,0.45)";
    ctx.shadowBlur = 0.6;
    ctx.fillStyle = "rgba(10,10,10,0.95)";
    let x = 0;
    for (const f of fila) {
      ctx.fillText(f.t, x, 0);
      x += f.w + gap;
    }
    ctx.restore();
  }
  ctx.restore();
}

function mousePressed() {
  if (mouseX >= 0 && mouseX <= W && mouseY >= 0 && mouseY <= H) generar();
}

function keyPressed() {
  if (key === " ") generar();
  if (key === "s" || key === "S") saveCanvas("circuitos-tinta-" + seed, "png");
}